﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CollabFast.Models;

namespace CollabFast.Tests.Models
{
    class TestProject
    {
        public static Project testProject = new Project();

    }
}
