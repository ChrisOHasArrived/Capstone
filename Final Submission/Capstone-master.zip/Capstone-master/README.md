# Capstone
Simple Web based collaboration application

[Backlog](https://trello.com/b/BPVMOYNi/goldfinger)
